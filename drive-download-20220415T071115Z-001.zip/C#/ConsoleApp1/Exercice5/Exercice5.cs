﻿// See https://aka.ms/new-console-template for more information
static int carré(int nombre)
{
    nombre = nombre * nombre;
    return nombre;
}

Console.WriteLine(carré(18));
Console.WriteLine(carré(5));
