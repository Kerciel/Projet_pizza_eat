﻿// See https://aka.ms/new-console-template for more information
class COVID
{
    private const string URL  =  "https://coronavirusapifr.herokuapp.com/data/live/departement/";
    static void Main(string[]arg)
    {
        Console.WriteLine("Resultats des informations sur le covid par rapport à un département:");


        string departemententrer = Console.ReadLine();
    }
}
